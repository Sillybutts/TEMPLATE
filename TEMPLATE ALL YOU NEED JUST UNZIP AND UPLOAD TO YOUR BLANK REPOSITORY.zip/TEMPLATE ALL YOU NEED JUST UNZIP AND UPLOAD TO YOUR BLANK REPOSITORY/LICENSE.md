license:cc-by-nc-sa-4.0

https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode
