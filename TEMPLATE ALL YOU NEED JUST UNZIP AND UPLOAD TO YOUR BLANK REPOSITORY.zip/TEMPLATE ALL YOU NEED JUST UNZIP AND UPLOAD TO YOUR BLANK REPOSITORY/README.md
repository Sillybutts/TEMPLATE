# REPOSITORY NAME

## Description


All STLs were exported in print orientation. STEP and F3D are also provided.


## Misc.

**If you are having issues with any of my designs, let me know on Discord (USERNAME#0000) or Reddit (u/USERNAME).**

**If you wish to print and sell this item, please contact me for licensing. I can be reached on Discord (USERNAME#0000) or Reddit (u/USERNAME).**

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.


## If you like what I do, please consider supporting me!

**I don't charge for my files, so any donations or merch purchases would be greatly appreciated!**

<a href="https://www.redbubble.com/people/USERNAME/shop/"><img alt="RedBubble Button" style="border-width:0" src="GHimages/RedbubbleButton.png" height="50" /></a> REDBUBBLE LINK

<a href="https://www.patreon.com/USERNAME/"><img alt="Patreon Button" style="border-width:0" src="GHimages/PatreonButton.png" height="50" /></a> PATREON LINK

<a href="https://www.buymeacoffee.com/USERNAME/"><img alt="BuyMeACoffee Button" style="border-width:0" src="GHimages/buymeacoffeeButton2.png" height="50" /></a> BUYMEACOFFEE LINK


## Images

<img src="GHimages/FILENAME FROM THE URL OF THE FILE WHEN YOU VIEW IT ON GITHUB" width="500">
